import numpy as np
import pandas as pd
from sklearn import cross_validation as cv
from sklearn.cross_validation import KFold
from sklearn.ensemble import RandomForestRegressor

data = pd.read_csv("Hoam_Loan_clean.csv",header = 0)
data_set = data[data.columns[0:11]]
target_set = data[data.columns[11]]

max_score = 0
best_n = 0
for n in range(1,100):
    rfc_scr = 0.
    rfc = RandomForestRegressor(n_estimators=n)
    for train in KFold(len(data_set), n_folds=10, shuffle=True):
        rfc.fit(data_set, target_set)
        rfc_scr += rfc.score(data_set, target_set)/10
    if rfc_scr > max_score:
        max_score = rfc_scr
        best_n = n

max_score_m = 0
best_m = 0
for m in range(1,100):
    rfc_scr = 0.
    rfc = RandomForestRegressor(max_depth=m)
    for train in KFold(len(data_set), n_folds=10, shuffle=True):
        rfc.fit(data_set, target_set)
        rfc_scr += rfc.score(data_set, target_set)/10
    if rfc_scr > max_score_m:
        max_score_m = rfc_scr
        best_m = m

rfc = RandomForestRegressor(n_estimators = n,max_depth = m )
rfc.fit(data_set, target_set)
rfc_scr = rfc.score(data_set, target_set)

x=np.array([201518,2,2,180,1,2,1,59,1,4,1]).reshape((1,-1))

rfc.predict(x)
