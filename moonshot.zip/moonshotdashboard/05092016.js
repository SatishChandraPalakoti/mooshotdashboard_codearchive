var kafka = require('kafka-node');
var Producer = kafka.Producer;
var KeyedMessage = kafka.KeyedMessage;
var Client = kafka.Client;
//var client = new Client('ec2-52-39-155-4.us-west-2.compute.amazonaws.com:2181');
var client = new Client('ec2-52-43-135-89.us-west-2.compute.amazonaws.com:2181');
var topic = 'testing';
var producer = new Producer(client, { requireAcks: 1 });
var express = require('express')
var app=express()
var alfa=express.Router()
var port=process.env.PORT || 5001


app.use(function(req, res, next) {
 res.setHeader('Access-Control-Allow-Origin', '*');
 res.setHeader('Access-Control-Allow-Methods', 'GET, POST');
 res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type,Authorization');
 next();
});



producer.on('ready', function () {

	alfa.get('/streams=:streams',function(req,res){

	var i=req.params.streams;
	while(i!=0)
		{
	var SimulateInput=""


	var min = 0,
        max = 1,
        gender = (Math.random() * (max - min) + min).toFixed(0);
        SimulateInput+=gender+","

	var min = 18.00,
        max = 65.00,
        age = (Math.random() * (max - min) + min).toFixed(2); 
	SimulateInput+=age+"," 
    
	 
	var min = 0.00,
        max = 28.00,
        debt = (Math.random() * (max - min) + min).toFixed(2); 
	SimulateInput+=debt+"," 


	var min = 1,
        max = 2,
        marital = (Math.random() * (max - min) + min).toFixed(0); 
	SimulateInput+=marital+"," 

	var edulevel=[1,2,3,4,5,7,8,9,10,11,12,13,14]	
		var min = 0,
        max = 7,
        qlevel = edulevel[(Math.random() * (max - min) + min).toFixed(0)]; 
	SimulateInput+=qlevel+","

	var race=[1,2,3,4,5,7,8,9]	
		var min = 0,
        max = 7,
        ethnicity = race[(Math.random() * (max - min) + min).toFixed(0)]; 
	SimulateInput+=ethnicity+"," 

	 	
		var min = 0,
        max = 25,
        yrsempl = (Math.random() * (max - min) + min).toFixed(0); 
	SimulateInput+=yrsempl+"," 	

	var min = 0,
        max = 1,
        priordefault = (Math.random() * (max - min) + min).toFixed(0); 
	SimulateInput+=priordefault+"," 


	var min = 0,
        max = 1,
        employed = (Math.random() * (max - min) + min).toFixed(0); 
	SimulateInput+=employed+"," 


	var creditsc=[0,1,2,3,4,5,7,8,9,10,11,12,13,14,15,16,17,19,20,23,40,67]	
		var min = 0,
        max = 21,
        credit = creditsc[(Math.random() * (max - min) + min).toFixed(0)]; 
	SimulateInput+=credit+"," 


	var min = 0,
        max = 1,
        license = (Math.random() * (max - min) + min).toFixed(0); 
	SimulateInput+=String(license)+"," 


	var min = 1,
        max = 2,
        citizen = (Math.random() * (max - min) + min).toFixed(0); 
	SimulateInput+=String(citizen)+"," 


	var zipcode=[0,17,20,21,22,24,28,29,30,32,40,43,45,49,50,52,56,60,62,70,73,76,80,86,88,92,93,94,96,99,100,102,108,110,112,117,120,121,128,129,130,132,136,140,141,144,145,150,152,154,156,160,163,164,167,168,170,171,174,176,178,180,181,184,186,188,195,200,202,204,208,210,211,212,216,220,221,224,225,228,230,231,232,239,240,250,252,253,254,256,260,263,268,272,274,276,280,288,290,292,300,303,309,311,312,320,329,330,333,340,348,349,350,352,356,360,368,369,370,371,372,375,380,381,383,393,395,396,399,400,408,410,411,416,420,422,431,432,434,440,443,450,454,455,460,465,470,480,487,491,500,510,515,519,520,523,550,560,583,600,640,680,711,720,760,840,928,980,1160,2000]
 	var min = 0,
        max = 169,
        area = zipcode[(Math.random() * (max - min) + min).toFixed(0)]; 
	SimulateInput+=area+"," 


	var min = 0,
        max = 1,
        incomeb = (Math.random() * (max - min) + min).toFixed(0);
        if(incomeb==0){
        lmin=0;
        lmax=700;
          incomeb1 = (Math.random() * (lmax - lmin) + lmin).toFixed(2);
          finalincome=incomeb1; 
        }
        else{
          hmin=1000;
        hmax=6000;
          incomeb2 = (Math.random() * (hmax - hmin) + hmin).toFixed(2);
          finalincome=incomeb2;   
        }
        SimulateInput+=finalincome


		producer.send([
        { topic: topic, partition: 0, messages: [SimulateInput], attributes: 0 }
    ], 
    function (err, result) {
        console.log(err || result); 
    });


producer.on('error', function (err) {
    console.log('error', err)
});

			i--;
		}
		res.json({streamed: req.params.streams})
		//res.send("Msg Sent to Zookeeper")
		//res.send(SimulateInput)
		console.log(SimulateInput)

	})

 });
app.use('/',alfa)
 app.listen(port) 
 console.log("Listening at the port: "+ port)
