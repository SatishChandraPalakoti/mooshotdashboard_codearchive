var kafka = require('kafka-node');
var Producer = kafka.Producer;
var KeyedMessage = kafka.KeyedMessage;
var Client = kafka.Client;
var client = new Client('ec2-52-39-155-4.us-west-2.compute.amazonaws.com:2181');
var topic = 'stream';
var producer = new Producer(client, { requireAcks: 1 });

producer.on('ready', function () {
   producer.send([
        { topic: topic, partition: 0, messages: ["Hello Satish,Sindhu,,Sk3,Chotu"], attributes: 0 }
    ], function (err, result) {
        console.log(err || result);
        process.exit();
    });
});

producer.on('error', function (err) {
    console.log('error', err)
});
